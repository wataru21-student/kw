# -*- coding: utf-8 -*-
from flask import Flask, render_template
import pandas as pd
import plotly.graph_objects as go

app = Flask(__name__)

@app.route('/')
def index():
    # CSVファイルの読み込み
    data = pd.read_csv('sales_data.csv')

    # グラフの作成
    fig = go.Figure(data=go.Scatter(x=data['0'], y=data['0'], mode='lines'))
    fig.update_layout(
        title='動的なグラフ',
        xaxis_title='X軸',
        yaxis_title='Y軸'
    )

    # グラフをHTML形式に変換
    graph_html = fig.to_html(full_html=False)

    # グラフの表示
    return render_template('index.html', graph_html=graph_html)

if __name__ == '__main__':
    app.run(debug=True)
      