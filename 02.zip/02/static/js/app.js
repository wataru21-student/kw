// 現在の日付を表示
var currentDateElement = document.getElementById("currentDate");
var currentDate = new Date();
var options = {
  weekday: "long",
  year: "numeric",
  month: "long",
  day: "numeric",
};
currentDateElement.textContent =
  "現在の日付: " + currentDate.toLocaleDateString("ja-JP", options);

// 選択された月の売り上げグラフを表示（ダミーデータ）
// 以下省略
