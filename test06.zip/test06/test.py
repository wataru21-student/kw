import pandas as pd
# -*- coding: utf-8 -*-
from flask import Flask, render_template
import pandas as pd
import plotly.graph_objects as go

data = pd.read_csv('test06\sales12.csv')
label = pd.read_csv("test06\label.csv",encoding='UTF-8')
data = data.fillna(0) 
print(data)
print(label)
data = pd.DataFrame(data)
data = data.T
data = data.reset_index()

month_data = pd.concat([label["商品名"],data["May-23"]],axis=1)

rank = month_data.sort_values("May-23",ascending=False)


print(rank)


"""
 # グラフの作成
fig = go.Figure(data=go.Bar(x=data["index"], y=data["May-23"]))
fig.update_layout(
    title='動的なグラフ',
    xaxis_title='X軸',
    yaxis_title='Y軸'
    )

fig01 = go.Figure(data=go.Table(header=dict(values=["企業名","売上"]),cells=dict(values=[data["index"],data["May-23"]])))


fig.show()
"""