# -*- coding: utf-8 -*-
from flask import Flask, render_template ,request
import pandas as pd
import plotly.graph_objects as go

app = Flask(__name__)


@app.route("/")
def index():
    return render_template('index.html')

@app.route("/sales", methods=["GET", "POST"])
def sales():
    #month = request.form['month']
    month = request.form['month']
    # CSVファイルの読み込み
    data = pd.read_csv('test06/sales12.csv')
    label = pd.read_csv("test06\label.csv",encoding='UTF-8')
    data = pd.DataFrame(data)
    data = data.fillna(0) 
    data = data.T
    data = data.reset_index()

    month_data = pd.concat([label["商品名"],data[month]],axis=1)

    rank = month_data.sort_values(month,ascending=False)
    rank = rank.head(10)
    # グラフの作成
    fig = go.Figure(data=go.Bar(x=month_data["商品名"], y=month_data[month]))
    fig.update_layout(
    xaxis_title='商品名',
    yaxis_title='売上'
    )


    fig01 = go.Figure(data=go.Table(header=dict(values=["商品名","売上"]),cells=dict(values=[rank["商品名"],rank[month]])))
    fig01.update_layout(margin=dict(t=10, l=30, r=40))
    
    # グラフをHTML形式に変換
    graph_html = fig.to_html(full_html=False)
    graph01_html = fig01.to_html(full_html=False)

    # グラフの表示
    return render_template('sales.html', graph_html=graph_html,graph01_html=graph01_html)
    
if __name__ == '__main__':
    app.run(debug=True)
      